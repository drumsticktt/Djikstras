# SFML 2.4 nuklear backend

This backend provides support for [SFML 2.4](http://www.sfml-dev.org). It will work on all platforms supported by SFML.

## Compiling

You have to edit the Makefile provided so that you can build the demo. Edit the SFML_DIR variable to point to your SFML root folder. This will be the folder to which SFML was installed and contains the lib and include folders.

On Linux there is an extra step. You need to install the the udev development files.
